# This Python script contains some Map-reduce code
